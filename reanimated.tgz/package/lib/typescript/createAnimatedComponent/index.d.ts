export { createAnimatedComponent } from './createAnimatedComponent';
